from django.shortcuts import render
from django.template.loader import get_template
from schoolinfowebsite.models import MajorSchool, FirstTierScore
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import HttpResponse, Http404, HttpResponseRedirect
from .form import FilterForm, ScoreSearchForm
from django.db.models import Q
from functools import reduce
import operator


# Create your views here.

def homepage(request):
    search_key_word = ''
    if 'wd' in request.GET:
        search_key_word = request.GET['wd']
    return render(request, 'major.html', context={'wd': search_key_word})


def score_search(request):
    search_key_word = ''
    if 'wd' in request.GET:
        search_key_word = request.GET['wd']
        print(search_key_word)
    return render(request, 'score.html', context={'wd': search_key_word})


def major_search(request):
    search_key_word = ''
    if 'wd' in request.GET:
        search_key_word = request.GET['wd']
    return render(request, 'major.html', context={'wd': search_key_word})



def get_first_tier_socre(admission_year, score_type):
    score = FirstTierScore.objects.filter(Q(admission_year__exact=admission_year) & Q(score_type__exact=score_type)).values('score')[0]['score']
    return score


def show_majorschool(request, major_domain):
    form = FilterForm(request.GET)
    search_key_word = ''
    if 'wd' in request.GET:
        search_key_word = request.GET['wd']
        return render(request, 'majorschool.html', context={'wd': search_key_word})
    query_filter = []
    score_diff = []
    ordering = ''
    direction = '-'
    if 'order_by' in request.GET:
        ordering = request.GET['order_by']

    if form.is_valid():
        school = form.cleaned_data['school']
        admission_year = form.cleaned_data['admission_year']
        min_score = form.cleaned_data['min_score']
        max_score = form.cleaned_data['max_score']
        filter_school = ('major_school__exact', school)
        filter_admission_year = ('admission_year__exact', admission_year)
        filter_min_score = ('min_score__gte', min_score)
        filter_max_score = ('max_score__lte', max_score)
        for key, values in form.cleaned_data.items():
            if values and key != 'page':
                query_filter.append(locals()['filter_{}'.format(key)])
    else:
        school = ''
        admission_year = ''
        min_score = ''
        max_score = ''

    if not query_filter:
        try:
            if ordering:
                majorschool_list = MajorSchool.objects.filter(major_domain=major_domain).order_by(direction+ordering)
                score_diff = [x.min_score - get_first_tier_socre(x.admission_year, x.major_type)
                              if x.min_score else None for x in majorschool_list]
            else:
                majorschool_list = MajorSchool.objects.filter(major_domain=major_domain).order_by('major_school')
                score_diff = [x.min_score - get_first_tier_socre(x.admission_year, x.major_type)
                              if x.min_score else None for x in majorschool_list]
        except MajorSchool.DoesNotExist:
            raise Http404('找不到制定专业的数据')

    else:
        query_list = [Q(x) for x in query_filter]
        try:
            if ordering:
                majorschool_list = MajorSchool.objects.filter(major_domain=major_domain).filter(
                    reduce(operator.and_, query_list)).order_by(direction+ordering)
                score_diff = [x.min_score - get_first_tier_socre(x.admission_year, x.major_type)
                              if x.min_score else None for x in majorschool_list]
            else:
                majorschool_list = MajorSchool.objects.filter(major_domain=major_domain).filter(
                    reduce(operator.and_, query_list)).order_by('major_school')
                score_diff = [x.min_score - get_first_tier_socre(x.admission_year, x.major_type)
                              if x.min_score else None for x in majorschool_list]
        except MajorSchool.DoesNotExist:
            raise Http404('找不到制定数据')

    # page = request.GET.get('page', 1)
    # paginator = Paginator(majorschool_list, 12)
    # paginator2 = Paginator(score_diff, 12)
    # try:
    #     majorschool = paginator.page(page)
    #     score_diff = paginator2.page(page)
    # except PageNotAnInteger:
    #     majorschool = paginator.page(1)
    #     score_diff = paginator2.page(1)
    # except EmptyPage:
    #     majorschool = paginator.page(paginator.num_pages)
    #     score_diff = paginator2.page(paginator2.num_pages)

    return render(request, 'majorschool.html', context={'major_record': majorschool_list,
                                                        'school': school,
                                                        'admission_year': admission_year,
                                                        'min_score': min_score,
                                                        'max_score': max_score,
                                                        'form': form,
                                                        'score_diff': score_diff,
                                                        'ordering': ordering,
                                                        'direction': direction})

def show_socre_search(request):
    form = ScoreSearchForm(request.GET)
    query_filter = []
    score_diff = []
    if form.is_valid():
        major_type = form.cleaned_data['major_type']
        min_score = form.cleaned_data['min_score']
        max_score = form.cleaned_data['max_score']
        filter_major_type = ('major_type__exact', major_type)
        filter_min_score = ('min_score__gte', min_score)
        filter_max_score = ('max_score__lte', max_score)
        for key, value in form.cleaned_data.items():
            if value and key != 'page':
                query_filter.append(locals()['filter_{}'.format(key)])
    else:
        major_type = ''
        min_score = ''
        max_score = ''

    if not query_filter:
        return HttpResponseRedirect('../')
    else:
        query_list = [Q(x) for x in query_filter]
        try:
            results_list = MajorSchool.objects.filter(reduce(operator.and_, query_list)).order_by('major_school')
            score_diff = [x.min_score - get_first_tier_socre(x.admission_year, x.major_type)
                          if x.min_score else None for x in results_list]
        except MajorSchool.DoesNotExist:
            raise Http404('找不到制定数据')

    # page = request.GET.get('page', 1)
    # paginator = Paginator(results_list, 12)
    # try:
    #     result = paginator.page(page)
    # except PageNotAnInteger:
    #     result = paginator.page(1)
    # except EmptyPage:
    #     result = paginator.page(paginator.num_pages)

    return render(request, 'score.html', context={'result': results_list,
                                                  'major_type': major_type,
                                                  'min_score': min_score,
                                                  'max_score': max_score,
                                                  'form': form,
                                                  'score_diff': score_diff})






