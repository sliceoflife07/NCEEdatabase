from django.apps import AppConfig


class SchoolinfowebsiteConfig(AppConfig):
    name = 'schoolinfowebsite'
