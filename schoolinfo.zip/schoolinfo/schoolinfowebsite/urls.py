from schoolinfowebsite.views import show_majorschool, score_search, major_search, show_socre_search

from django.urls import re_path,path
urlpatterns = [
    path('major/', major_search, name='major-search'),
    re_path(r'^major/(?P<major_domain>[0-9]{1,2})/$', show_majorschool, name='major-school'),
    path('score/', score_search, name='score-search'),
    path('score/search-results/', show_socre_search, name='search-results')
]
