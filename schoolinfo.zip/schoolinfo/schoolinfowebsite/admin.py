from django.contrib import admin
from schoolinfowebsite.models import School, Major, MajorSchool, FirstTierScore
from import_export import resources
from import_export.admin import ImportExportModelAdmin
# Register your models here.


class SchoolResource(resources.ModelResource):
    class Meta:
        model = School
        import_id_fields = ('school_id',)
        fields = ('school_id', 'school_name', 'school_985', 'school_211', 'school_fir')


class MajorSchoolResource(resources.ModelResource):
    class Meta:
        model = MajorSchool
        import_id_fields = ('major_record',)
        fields = ('major_record', 'major_school', 'major_name', 'major_type', 'major_domain',
                  'min_score', 'avg_score', 'max_score', 'admission_year')


class MajorResource(resources.ModelResource):
    class Meta:
        model = Major
        import_id_fields = ('major_id',)
        fields = ('major_id', 'major_name',)


class FirstTierScoreResource(resources.ModelResource):
    class Meta:
        model = FirstTierScore
        import_id_fields = ('score_id',)
        fields = ('score_id', 'score_type', 'admission_year', 'score',)


class SchoolAdmin(ImportExportModelAdmin):
    resource_class = SchoolResource

    class Meta:
        model = School

    list_display = ['school_name', 'display_985', 'display_211', 'display_fir', 'school_area']

    def display_985(self, obj):
        if obj.school_985 == '0':
            return '否'
        else:
            return '是'

    def display_211(self, obj):
        if obj.school_211 == '0':
            return '否'
        else:
            return '是'

    def display_fir(self, obj):
        if obj.school_fir == '0':
            return '否'
        else:
            return '是'

    display_985.short_description = '是否为985'
    display_211.short_description = '是否为211'
    display_fir.short_description = '是否为双一流'


class MajorSchoolAdmin(ImportExportModelAdmin):
    resource_class = MajorSchoolResource

    class Meta:
        model = MajorSchool

    list_display = ['major_school', 'major_name', 'major_type', 'min_score', 'avg_score', 'max_score', 'admission_year']


class MajorAdmin(ImportExportModelAdmin):
    resource_class = MajorResource

    class Meta:
        model = Major

    list_display = ['major_id', 'major_name']


class FirstTierScoreAdmin(ImportExportModelAdmin):
    resource_class = FirstTierScoreResource

    class Meta:
        model = FirstTierScore

    list_display = ['score_type', 'admission_year', 'score']


admin.site.register(School, SchoolAdmin)
admin.site.register(MajorSchool, MajorSchoolAdmin)
admin.site.register(Major, MajorAdmin)
admin.site.register(FirstTierScore, FirstTierScoreAdmin)