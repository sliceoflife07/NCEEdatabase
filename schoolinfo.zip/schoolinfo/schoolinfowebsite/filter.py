from schoolinfowebsite.models import MajorSchool
import django_filters


class MajorSchoolFilter(django_filters.FilterSet):
    class Meta:
        model = MajorSchool
        fields = ['major_school', 'admission_year']