from django.db import models
from django.urls import reverse


# Create your models here.


class School(models.Model):
    school_id = models.AutoField(primary_key=True, verbose_name='学校编号')
    school_name = models.CharField(max_length=25, blank=False, verbose_name='学校名称')
    IS_985 = (('0', '非985'),
              ('1', '985'),)
    IS_211 = (('0', '非211'),
              ('1', '211'),)
    IS_FIR = (('0', '非双一流'),
              ('1', '双一流'),)
    school_985 = models.CharField(max_length=1, choices=IS_985, blank=False, verbose_name='是否为985')
    school_211 = models.CharField(max_length=1, choices=IS_211, blank=False, verbose_name='是否为211')
    school_fir = models.CharField(max_length=1, choices=IS_FIR, blank=False, verbose_name='是否为双一流')
    school_area = models.CharField(max_length=10, blank=True, verbose_name='学校所在地区')

    class Meta:
        ordering = ['school_name']
        verbose_name = '学校'
        verbose_name_plural = '学校'

    #  This string is used to represent individual records in the administration site
    def __str__(self):
        return str(self.school_name)  # 创建后在html中被显示的方式


class Major(models.Model):
    ID_CHOICE = (('0', '临床医学'),
                 ('1', '麻醉学'),
                 ('2', '口腔医学'),
                 ('3', '金融学'),
                 ('4', '会计学'),
                 ('5', '经济学'),
                 ('6', '法学'),
                 ('7', '建筑学'),
                 ('8', '信息安全'),
                 ('9', '应用数学'),
                 ('10', '针灸推拿学'),
                 ('11', '康复治疗学'))
    major_id = models.CharField(primary_key=True, choices=ID_CHOICE, max_length=2, verbose_name='专业编号')
    major_name = models.CharField(max_length=20, verbose_name='专业名称')

    class Meta:
        verbose_name = '专业'
        verbose_name_plural = '专业'

    def get_absolute_url(self):
        return reverse('major_detail', args=[str(self.major_name)])

    def __str__(self):
        return str(self.major_name)


class MajorSchool(models.Model):
    major_record = models.AutoField(primary_key=True,)
    major_school = models.ForeignKey('School', on_delete=models.PROTECT, verbose_name='开设院校')
    major_name = models.CharField(max_length=20, verbose_name='专业名称', blank=False)
    MAJOR_TYPE = (('0', '文史'),
                  ('1', '理工'),)
    major_type = models.CharField(max_length=1, choices=MAJOR_TYPE, blank=False, verbose_name='招生类型')
    major_domain = models.ForeignKey('Major', on_delete=models.PROTECT, verbose_name='专业类别')
    min_score = models.PositiveSmallIntegerField(verbose_name='录取最低分', blank=True, null=True)
    avg_score = models.PositiveIntegerField(verbose_name='录取平均分', blank=True, null=True)
    max_score = models.PositiveIntegerField(verbose_name='录取最高分', blank=True, null=True)
    admission_year = models.CharField(max_length=4, verbose_name='录取年份')

    class Meta:
        verbose_name = '专业及开设学校'
        verbose_name_plural = '专业及开设学校'

    def __str__(self):
        return "{0}-{1}".format(self.major_name, self.major_school)


class FirstTierScore(models.Model):
    score_id = models.AutoField(primary_key=True)
    admission_year = models.CharField(max_length=4, verbose_name='年份')
    SCORE_TYPE = (('0', '文史'),
                  ('1', '理工'))
    score_type = models.CharField(max_length=1,choices=SCORE_TYPE, blank=False, verbose_name='分数类型')
    score = models.PositiveIntegerField(verbose_name='分数')

    class Meta:
        verbose_name = '一本分数线信息'
        verbose_name_plural = '一本分数线信息'

    def __str__(self):
        return "{0}:({1}){2}".format(self.admission_year, self.score_type, self.score)