from django import forms
from .models import School


class FilterForm(forms.Form):
    year_choice = (('', ''), ('2013', '2013'), ('2014', '2014'), ('2015', '2015'), ('2016', '2016'), ('2017', '2017'))
    admission_year = forms.ChoiceField(label="录取年份", choices=year_choice, required=False)
    min_score = forms.IntegerField(label='最低分', min_value=0, max_value=750, required=False)
    max_score = forms.IntegerField(label='最高分', min_value=0, max_value=750, required=False)
    school = forms.CharField(label='院校', max_length=100, required=False)

    def clean(self):
        cleaned_data = super().clean()
        max_score = cleaned_data.get('max_score')
        min_score = cleaned_data.get('min_score')
        if cleaned_data['school'] != '':
            cleaned_data['school'] = School.objects.get(school_name__exact=cleaned_data['school'].strip('')).school_id
        if (max_score is not None) and (min_score is not None):
            if max_score < min_score:
                raise forms.ValidationError('最高分应至少大于等于最低分')


class ScoreSearchForm(forms.Form):
    major_type_choice = (('', ''), ('0', '文史'), ('1', '理工'))
    min_score = forms.IntegerField(label='最低分', min_value=0, max_value=750, required=False)
    max_score = forms.IntegerField(label='最高分', min_value=0, max_value=750, required=False)
    major_type = forms.ChoiceField(label='考生类型', choices=major_type_choice, required=False)

    def clean(self):
        cleaned_data = super().clean()
        max_score = cleaned_data.get('max_score')
        min_score = cleaned_data.get('min_score')
        if (max_score is not None) and (min_score is not None):
            if max_score < min_score:
                raise forms.ValidationError('最高分应至少大于等于最低分')

