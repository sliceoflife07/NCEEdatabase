#!/bin/bash

# Start Gunicorn processes
echo Starting Gunicorn.
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo $DIR
cd "$DIR/venv"; source ./bin/activate;
cd ../;
exec gunicorn schoolinfo.wsgi:application \
    --bind 0.0.0.0:8000 \
    --workers 9
